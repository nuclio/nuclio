def handler(context, event):
	return "hello world"
